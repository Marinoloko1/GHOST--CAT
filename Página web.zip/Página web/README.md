# ![icon-document](https://github.com/Gloper98/menu-hamburguesa/raw/master/assets/images/icon-document.png "document") Menu Hamburguesa
Un menú de hamburguesa nos permite tener escondido el menú y únicamente mostrar un botón (3 líneas horizontales) que cuando lo apretamos (o hacemos click), se muestra en la pantalla todas las opciones del menú.

## Caso practico numero tres


![burguer-menu](https://github.com/Gloper98/menu-hamburguesa/raw/master/assets/images/burguer.gif "burguer-menu")
>Modelo: Menu hamburguesa.